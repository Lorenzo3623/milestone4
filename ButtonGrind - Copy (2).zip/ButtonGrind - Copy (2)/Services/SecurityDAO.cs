﻿using ButtonGrind.Models;
using System.Data.SQLite;
using System.Collections.Generic;
using System.Data.SqlClient;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Drawing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace ButtonGrind.Services
{
    public class SecurityDAO
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog = Test; Integrated Security = True; Connect Timeout = 30; Encrypt=False;TrustServerCertificate=False;ApplicationIntent = ReadWrite; MultiSubnetFailover=False";
		public bool FindUserByNameAndPassword(UserModel user)
        {
            //assume nothing is found
            bool success = false;

            string sqlStatement = "SELECT * FROM dbo.Users WHERE username = @username and password = @password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                // define the values of the two placeholders in the sqlStatement string
                command.Parameters.Add("@USERNAME", System.Data.SqlDbType.VarChar, 50).Value = user.UserName;
                command.Parameters.Add("@PASSWORD", System.Data.SqlDbType.VarChar, 50).Value = user.Password;
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                        success = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return success;
        }
        public bool InsertUser(UserModel user)
        {
            bool success = false;
            string sqlStatement = "INSERT INTO dbo.users" +
                                  "(FirstName, LastName, Sex, Age, State, Email, Username, Password) " +
                                  "VALUES (@FirstName, @LastName, @Sex, @Age, @State, @Email, @Username, @Password)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@FirstName", System.Data.SqlDbType.NVarChar, 50).Value = user.FirstName;
                command.Parameters.Add("@LastName", System.Data.SqlDbType.NVarChar, 50).Value = user.LastName;
                command.Parameters.Add("@Sex", System.Data.SqlDbType.NVarChar, 10).Value = user.Sex;
                command.Parameters.Add("@Age", System.Data.SqlDbType.Int).Value = user.Age;
                command.Parameters.Add("@State", System.Data.SqlDbType.NVarChar, 50).Value = user.State;
                command.Parameters.Add("@Email", System.Data.SqlDbType.NVarChar, 100).Value = user.Email;
                command.Parameters.Add("@Username", System.Data.SqlDbType.NVarChar, 20).Value = user.Username;
                command.Parameters.Add("@Password", System.Data.SqlDbType.NVarChar, 100).Value = user.Password; // Remember to hash passwords in real applications
                                                                                                                // Server side error check
                try
                {
                    connection.Open();
                    int result = command.ExecuteNonQuery();
                    success = result > 0;
                }
                catch (Exception ex)
                {
                    // Consider logging the exception
                    Console.WriteLine(ex.Message);
                }
            }

            return success;
        }
    }
}