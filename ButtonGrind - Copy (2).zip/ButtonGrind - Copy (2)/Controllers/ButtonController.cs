﻿using ButtonGrind.Models;
using Microsoft.AspNetCore.Mvc;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ButtonGrind.Controllers
{
    // Defines the controller for handling button actions in the application.
   

    public class ButtonController : Controller
    {
        int up=0, down=0, left=0, right=0;
        int row=0;
        int column=0;

        Random rand = new Random();

        // Create a list to hold the random numbers
        List<int> randomNumbers = new List<int>();
        List<int> numbers= new List<int>();
     

        // Specify the number of elements you want in your list
        int numberOfElements = 6;

        // Static list to hold the state of each button in the grid.
        static List<Models.ButtonModel> buttons = new List<ButtonModel>();

        // Random number generator for initializing button states.
        Random random = new Random();

        // Constant to define the size of the button grid.
        const int GRID_SIZE = 24;

        // Action method for the initial loading of the button grid.
        public IActionResult Index()
        {
            // Reinitialize the buttons list to start fresh each time the Index is loaded.
            buttons = new List<ButtonModel>();
        
            // Populating the buttons list with ButtonModel instances.
            for (int i = 0; i < GRID_SIZE; i++)
            {
                // Adds a new button with a random state (0 to 3).
                buttons.Add(new ButtonModel(i,1));
            }
            
           
            // Returns the Index view, passing the list of buttons to it.
            return View("Index", buttons);
        }

        // Action method to handle button click events.
        public IActionResult HandleButtonClick(string buttonNumber)
        {
            // Parses the button number from the string argument to an integer.
            int bN = int.Parse(buttonNumber);
         
            // Cycles the state of the clicked button through a range (0 to 3).
            for (int i = 0; i < numberOfElements; i++)
            {
                randomNumbers.Add(rand.Next(0, 24)); // Random number between 0 (inclusive) and 24 (exclusive)
            }
            // Variable to keep track of match
            bool matchFound = false;
            bool next = false;
            // Loop through the list and check if the number matches
            foreach (int number in randomNumbers)
            {
                if (number == bN)
                {
                    matchFound = true;
                    break; // Exit the loop as soon as a match is found
                }

            }
            foreach (int number in randomNumbers) {
                
                    row = number / 6;
                    column = number % 4;
                    IsNeighbor(bN, row, column);
                
                    if (IsNeighbor(bN, row, column)==true)
                    {
                     next = true;
                        break; // Exit the loop as soon as a match is found
                    }
                }
                // Output based on whether a match is found
                if (matchFound)
            {
                buttons.ElementAt(bN).ButtonState = 2;
                return View("View", buttons);
			}
			if (next)
			{
				buttons.ElementAt(bN).ButtonState = 4;
			}
			else
            {
                

                buttons.ElementAt(bN).ButtonState = 0;
            }
         
            //// Returns the Index view with the updated state of buttons.
            return View("Index", buttons);
        }
        public bool IsNeighbor(int selectedButton, int randomRow, int randomCol)
        {
            int numColumns = 4; // For a 6x4 grid
            int selectedRow = selectedButton / 6;
            int selectedCol = selectedButton % numColumns;

            // Check if the random cell is a neighbor
            return Math.Abs(selectedRow - randomRow) <= 1 && Math.Abs(selectedCol - randomCol) <= 1;
        }
    }
}
